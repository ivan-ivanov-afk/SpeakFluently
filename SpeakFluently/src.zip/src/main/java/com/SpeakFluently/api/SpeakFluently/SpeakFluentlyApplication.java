package com.SpeakFluently.api.SpeakFluently;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeakFluentlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeakFluentlyApplication.class, args);
	}

}
